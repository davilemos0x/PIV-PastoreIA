from flask import Flask, render_template, request, redirect, session, flash
from supabase import create_client, Client
from functools import wraps

app = Flask(__name__)
app.secret_key = "sua_chave_secreta"

SUPABASE_URL = "https://atmehdmrfbcsjcaviyvv.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF0bWVoZG1yZmJjc2pjYXZpeXZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNTY0MjYsImV4cCI6MjA3ODYzMjQyNn0.szKZ_PLTWYsc1g7cmetaRGOcRhDv39GoLoqQZyK76qA"

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)


# ---------------- DECORADOR DE LOGIN ---------------- #
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("logged"):
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function


@app.route("/")
def index():
    return redirect("/login")


# ---------------- LOGIN REAL ---------------- #
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        senha = request.form["senha"]

        try:
            response = supabase.auth.sign_in_with_password({
                "email": email,
                "password": senha
            })

            if response.session:
                session["logged"] = True
                session["user"] = email
                return redirect("/relatorio")
            else:
                flash("Credenciais inválidas", "erro")

        except Exception:
            flash("Erro ao autenticar. Verifique email e senha.", "erro")

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    session.clear()
    try:
        supabase.auth.sign_out()
    except:
        pass
    return redirect("/login")


# ---------------- ROTAS PRINCIPAIS ---------------- #
@app.route("/relatorio")
@login_required
def relatorio():
    try:
        response = supabase.table("detections").select("*").order("id", desc=True).execute()
        detections = response.data if response.data else []
    except:
        detections = []
    return render_template("relatorio.html", detections=detections)


@app.route("/detalhe/<int:detection_id>")
@login_required
def detalhe(detection_id):
    try:
        response = supabase.table("detections").select("*").eq("id", detection_id).single().execute()
        detection = response.data if response.data else None
    except:
        detection = None

    if not detection:
        flash("Detecção não encontrada", "erro")
        return redirect("/relatorio")

    return render_template("detalhe.html", detection=detection)


@app.route("/galeria")
@login_required
def galeria():
    try:
        response = supabase.table("detections").select("*").order("id", desc=True).execute()
        detections = response.data if response.data else []
    except:
        detections = []
    return render_template("galeria.html", detections=detections)


@app.route("/controle")
@login_required
def controle():
    return render_template("controle.html")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5005)

