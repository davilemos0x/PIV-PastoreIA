import sqlite3
import base64

# Criação e simulação do banco
conn = sqlite3.connect('database.db')
cur = conn.cursor()

# Limpa a tabela
cur.execute("DROP TABLE IF EXISTS detections")

#  Tabela de detecções
cur.execute("""
CREATE TABLE detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    detected_class TEXT NOT NULL,
    confidence_score REAL,
    camera_id INTEGER,
    paddock_id INTEGER,
    image_data TEXT
)
""")

# Simulação de imagens (duas ovelhas e dois predadores)
def fake_img(color):
    import io
    from PIL import Image
    img = Image.new("RGB", (100, 100), color=color)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()

detections = [
    ('2025-11-08 10:00:00', 'ovelha', 0.95, 1, 1, fake_img("white")),
    ('2025-11-08 10:05:00', 'predador', 0.87, 2, 1, fake_img("red")),
    ('2025-11-08 10:10:00', 'ovelha', 0.92, 1, 2, fake_img("gray")),
    ('2025-11-08 10:15:00', 'predador', 0.90, 3, 3, fake_img("brown"))
]

cur.executemany("""
INSERT INTO detections (timestamp, detected_class, confidence_score, camera_id, paddock_id, image_data)
VALUES (?, ?, ?, ?, ?, ?)
""", detections)

conn.commit()
conn.close()
print("Banco recriado com 4 detecções (IDs 1–4).")

